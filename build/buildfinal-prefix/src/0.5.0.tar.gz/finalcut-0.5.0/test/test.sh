#!/bin/sh
make test
