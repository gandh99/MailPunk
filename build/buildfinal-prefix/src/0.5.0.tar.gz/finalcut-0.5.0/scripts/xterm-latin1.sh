#!/bin/sh
luit -encoding POSIX ../examples/ui

