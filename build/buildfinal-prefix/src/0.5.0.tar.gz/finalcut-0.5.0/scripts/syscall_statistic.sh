#!/bin/sh
LD_LIBRARY_PATH=../src/.libs strace -c ../examples/.libs/ui

