#!/bin/bash
xfd -center -columns 16 -fn -misc-8x16graph-medium-r-normal--17-160-75-75-*-80-iso8859-1

