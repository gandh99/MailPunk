#!/bin/sh

hte ../examples/.libs/ui
