#!/bin/sh
showconsolefont

